const initialState = {
    searchValue: []
  };
  
  export default function lsjl(state = initialState, action) {
    switch (action.type) {
      case 'set_searchValue':
        return {
          ...state,
          searchValue: state.searchValue.concat(action.payload)
        };
        //创建一个新的动作类型 
        case 'clear_searchValue':
            return {
              ...state,
              searchValue: []
            };
      default:
        return state;
    }
  };
  