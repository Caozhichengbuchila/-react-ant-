export const setHSearchValue = (value) => {
    return {
      type: 'set_searchValue',
      payload: value
    }
  }
//清除历史记录动作
  export const clearHSearchValue = () => {
    return {
      type: 'clear_searchValue'
    }
  }
  