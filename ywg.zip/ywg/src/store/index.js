// 负责提供仓库对象
import { legacy_createStore as createStore} from 'redux'
import reducer from "./reducer.js"
export default createStore(reducer);