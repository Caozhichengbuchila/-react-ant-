import './App.css';
import Home  from './views/Home';
import { Route, Switch,} from "react-router-dom";
import Cate from "./views/Cate";
import Mk from './views/Mk';
import Detail from './views/Detail';
import Search from './views/Search';
function App() {
  return (
    <div className="App">
      <Switch>
      <Route exact path="/" component={Home}></Route>
        <Route exact path="/cate" component={Cate}></Route>
        <Route exact path="/mks/:id" component={Mk}></Route>
        <Route exact path="/detail/:productId" component={Detail}></Route>
        <Route exact path="/search" component={Search}></Route>
      </Switch>     
    </div>
  );
}

export default App;