import React from "react";
import { AppOutline,MessageOutline,BankcardOutline } from 'antd-mobile-icons'
import "./Gosmit.css"
const Gosmit =()=>{
    return(
        <div className="smit_box">
            <div className="sm_box1">
          <div><div><AppOutline fontSize={23} /></div><span>首页</span></div>
          <div><div><MessageOutline fontSize={23}/></div><span>客服</span></div>
          <div><div><BankcardOutline fontSize={23}/></div><span>进店</span></div>
          </div>
          <div className="sm_box2">
             <div className="sm_s1">加入购物车</div>
             <div className="sm_s2">立即购买</div>
          </div>
         
        </div>
    )
}
export default Gosmit;