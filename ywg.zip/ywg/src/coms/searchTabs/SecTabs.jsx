import React from 'react'
import { Tabs } from 'antd-mobile'

const SecTabs=()=>{
             return (
      <>
          <Tabs>
            <Tabs.Tab title='搜商品' key='fruits'>
            </Tabs.Tab>
            <Tabs.Tab title='搜商铺' key='vegetables'>
            </Tabs.Tab>
          </Tabs>
        </>
  )
}
export default SecTabs;