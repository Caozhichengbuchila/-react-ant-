import React from 'react';
import { Space, Swiper } from 'antd-mobile';
import './demo1.css'

function GoodImgsSwiper(props) {
  const {gdimages} = props;
  console.log(gdimages);
  const items = gdimages.map((image, index) => (<Swiper.Item key={index}>
    <div className="content323" style={{ backgroundImage: `url(${image})`, backgroundSize: '100% 100%', }}>
      {/* 仅被用作背景图片的来源。解决403报错*/}
      <img src={image} alt="" referrerPolicy="no-referrer" style={{ display: "none" }} />
    </div>
  </Swiper.Item>))
    return (<>    
        <Space direction='vertical' block>
          <Swiper
           loop={true} 
            indicator={(total, current) => (
              <div className="customIndicator">
                {`${current + 1} / ${total}`}
              </div>
            )}
          >
            {items}
          </Swiper>
        </Space>
    </>);
};
export default GoodImgsSwiper
