import React from "react";

const NavBar = () => {
  const titles = [
    {title: "限时秒杀", image: "https://img1.yiwugou.com/icon_index_xsms.png?v=3"},
    {title: "尾货清仓", image: "https://img1.yiwugou.com/icon_index_qingcang.png?v=3"},
    {title: "热卖", image: "https://static.yiwugou.com/wap/image/icon_index_whbk.png"},
    {title: "论坛", image: "https://img1.yiwugou.com/icon_index_bbs.png?v=3"},
    {title: "帮助中心", image: "https://img1.yiwugou.com/icon_index_tsbg.png?v=3"},
    {title: "产业带", image: "https://static.yiwugou.com/wap/image/icon_index_cyd.png"},
    {title: "转租转让", image: "https://img1.yiwugou.com/icon_index_zhuanzu.png?v=2"},
    {title: "求购与库存", image: "https://img1.yiwugou.com/icon_index_qgkc.png?v=2"},
    {title: "投诉曝光", image: "https://img1.yiwugou.com/icon_index_tsbg.png?v=3"},
    {title: "订货通", image: "https://static.yiwugou.com/wap/image/icon_index_vip_p.png"},
  ];

  return (
    <div style={styles.navContainer}>
      {[0, 1].map((rowIndex) => (
        <div style={styles.rowContainer} key={rowIndex}>
          {titles.slice(rowIndex * 5, (rowIndex + 1) * 5).map((titleObj) => (
            <div style={styles.itemContainer} key={titleObj.title}>
              <div style={{...styles.circle, backgroundImage: `url(${titleObj.image})`}}>
              <img src={titleObj.image} alt="" referrerPolicy="no-referrer" style={{ display: "none" }} />
              </div>
              <div style={styles.title}>{titleObj.title}</div>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

const styles = {
  navContainer: {
    width:'100%',
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  rowContainer: {
    width:'100%',
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent:"space-evenly"
  },
  itemContainer: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    margin: "10px"
  },
  circle: {
    width: "40px",
    height: "40px",
    borderRadius: "50%",
    backgroundColor: "#ccc",
    backgroundSize: "100% 100%",
  },
  title: {
    fontSize: "12px",
    fontWeight: "bold",
    textAlign: "center",
    marginTop: "5px"
  }
};

export default NavBar;
