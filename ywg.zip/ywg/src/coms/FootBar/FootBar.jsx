import React, { useState } from 'react';
import { TabBar } from 'antd-mobile';
import { AppOutline, MessageOutline, UnorderedListOutline, UserOutline, ShopbagOutline } from 'antd-mobile-icons';
import { useHistory } from 'react-router-dom';

const tabs = [
  {
    key: '/',
    title: '首页',
    icon: <AppOutline />,
  },
  {
    key: '/cate',
    title: '分类',
    icon: <UnorderedListOutline />,
  },
  {
    key: '/message',
    title: '消息',
    icon: <MessageOutline />,
  },
  {
    key: '/shopcar',
    title: '购物车',
    icon: <ShopbagOutline />
  },
  {
    key: '/mine',
    title: '我的',
    icon: <UserOutline />,
  },
];

function FootBar() {
  const history = useHistory();
  const [activeKey, setActiveKey] = useState('/');

  const handleTabChange = (key) => {
    setActiveKey(key);
    history.push(key);
    }
  return (
    <TabBar activeKey={activeKey} onChange={handleTabChange}>
      {tabs.map((tab) => (
        <TabBar.Item
          key={tab.key}
          title={tab.title}
          icon={tab.icon}
        />
      ))}
    </TabBar>
  );
}

export default FootBar;
