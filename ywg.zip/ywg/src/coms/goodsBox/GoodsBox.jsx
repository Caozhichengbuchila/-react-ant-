import './goodsbox.css'
import React from "react";
import { useHistory } from "react-router-dom";
import LazyLoad from 'react-lazyload';
import placeholder from "../../assets/yiwugo_default.jpg";

const GoodsBox = (props) => {
    const { goodsList } = props;
    const history = useHistory();
  
    const handleProductClick= (productId) => {
        history.push(`/detail/${productId}`);
        };
var holderImg = <img src={placeholder} alt=""/>
    return(
        
        <div className="goods_box">
            {/* 处理敏感图片 */}
            {goodsList.map((product) => {
                let img = product.picture2;
                let newImg = img;
                let index = img.indexOf('?');
                if (index !== -1) {
                    newImg = img.slice(0, index);
                }
                if (!img.startsWith('http')) {
                    newImg = `https://img1.yiwugou.com/${img}`;
                }
                return (
                    <div key={product.id} onClick={() => handleProductClick(product.id)}>
                          <LazyLoad placeholder={holderImg}> 
                          <img src={newImg} alt=""/>
                         {/* 解决渲染图片403报错 */}
                        <meta name="referrer" content="no-referrer"></meta>
                        </LazyLoad>
                        <p className="title">{product.title}</p>
                        <div className="price-container">
                            <span className="price">￥{product.sellPrice/100}</span>
                            <span className="batch">{product.startNum}{product.metric}起批</span>
                        </div>
                        <div className="shop-info">
                            <span>{product.shopName}</span>
                            <div className="shop-years">{product.shopYears}年</div>
                        </div>
                        <p className="market-address">{product.marketOrAdress}</p>
                    </div>
                );
            })}
        </div>
    );
};


export default GoodsBox;
