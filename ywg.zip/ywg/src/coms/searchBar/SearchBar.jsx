import './SearchBar.css'
import React,{ useState } from "react";
import { useHistory } from "react-router-dom";
import axios from "axios";
import { setHSearchValue  } from "../../store/actions"
import store from '../../store/index';

const SearchBar =({ onSearch,searchValue2  })=>{
  const history = useHistory();
  const [searchValue, setSearchValue] = useState("");
  const [hasSearch, setHasSearch] = useState(false);
  const [secResult,setSecResult]=useState([]);
 

  const handleClickToS = () => {
    history.push(`/search`);
  };

  const handleInputChange = (event) => {
    const newValue = event.target.value;
    setSearchValue(newValue);
    setHasSearch(false);
  };

  const handleSearchClick = () => {
    console.log(hasSearch,secResult);
    axios
    .get(
      `/ywg/api/search/s.htm?q=${searchValue}&cpage=1&pageSize=6&st=0&m=&f=&s=&imei=360755bd-f368-46ee-9e0d-c3c35b53ca2f&source=wap&userinfo=&searchMethod=randad&spm=d2FwLnlpd3Vnby5jb20v.d2FwLnlpd3Vnby5jb20vc2VhcmNo`
    )
      .then((response) => {  
        store.dispatch(setHSearchValue(searchValue));
        //查看历史记录是否存进redux
        console.log(store.getState().searchValue)
        console.log(response.data.prslist);
        const secResult = response.data.prslist;
        setSecResult(secResult);
        setHasSearch(true);
        if (onSearch) {
          onSearch(secResult);
        }
        setSearchValue(""); // 清空输入框

      })
      .catch(() => {
        setHasSearch(true);
      });
  };
  return (
    <div className="sc_bg">
      <div className='Title_l' onClick={() => history.goBack()}>义乌购</div>
      <input
        type="text"
        style={styles.searchInput}
        placeholder="请输入关键字..."
        autoFocus={false}
        onClick={() => handleClickToS()}
        value={searchValue || searchValue2}
        onChange={handleInputChange}
      />
      <div className='language' onClick={handleSearchClick}>
        搜索
      </div>
    </div>
  );
}

const styles = {
  searchInput: {
    height:"34px",
    borderRadius: "7px",
    border: "none",
    width: "265.2px",
    outline:'none'
    
  }
};
export default SearchBar;
