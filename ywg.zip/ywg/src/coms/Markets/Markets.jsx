import React from "react";
import './Markets.css';
import { useHistory } from "react-router-dom";

const Markets = () => {
  const images = [
    {    id:1001,
        title: '义乌国际商贸城一区',
        url: 'https://static.yiwugou.com/mobile/assets/yiqu.png'
    },
    {   
        id:10011,
        title: '义乌国际商贸城一区东',
        url: 'https://static.yiwugou.com/mobile/assets/yiqudong.png'
    },
    {   
        id:1003,
        title: '义乌国际商贸城二区',
        url: 'https://static.yiwugou.com/mobile/assets/erqu.png'
    },
    {
        id:10031,
        title: '义乌国际商贸城二区东',
        url: 'https://static.yiwugou.com/mobile/assets/erqudong3.png'
    },
    {
        id:1005,
        title: '义乌国际商贸城三区',
        url: 'https://static.yiwugou.com/mobile/assets/sanqu.png'
    },
    {
        id:1006,
        title: '义乌国际商贸城四区',
        url: 'https://static.yiwugou.com/mobile/assets/siqu.png'
    },
    {     
        id:1007,
        title: '义乌国际商贸城五区',
        url: 'https://static.yiwugou.com/mobile/assets/wuqu.png'
    },
    {    
        id:1008,
        title: '义乌篁园市场',
        url: 'https://static.yiwugou.com/mobile/assets/huangyuan.png'
    },
    { 
        id:1009,
        title: '义乌国际生产资料市场',
        url: 'https://static.yiwugou.com/mobile/assets/shengchanziliao.png'
    },
    {   id:10011,
        title: '义乌购城市馆',
        url: 'https://static.yiwugou.com/mobile/assets/chanyedai.png'
    }
];
const history = useHistory();

const handleClick = (id) => {
history.push(`/mks/${id}`);
};
  return (
    <div className="markets-container">
      {images.map((image, index) => (
        <div
          className="market-item"
          key={index}
          style={{
            backgroundImage: `url(${image.url})`,
            backgroundSize: '100% 100%',
          }}
          onClick={() => handleClick(image.id)}
        />
      ))}
    </div>
  );
};

export default Markets;
