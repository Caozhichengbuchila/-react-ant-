import React from "react";
const Shopcar =()=>{
    return(
        <div>
            <h1>购物</h1>
        </div>
    )
}
export default Shopcar;
