import React, { useEffect, useState } from "react";
import SearchBar from "../coms/searchBar/SearchBar";
import SecTabs from "../coms/searchTabs/SecTabs";
import GoodsBox from "../coms/goodsBox/GoodsBox.jsx";
import './CSS/Search.css';
import { clearHSearchValue } from '../store/actions';
import store from '../store/index';
import axios from "axios";

const Search = () => {
  const [hotList, setHotList] = useState([]);
  const [showHotList, setShowHotList] = useState(true);
  const [secResult, setSecResult] = useState([]);
  const [searchValue2, setSearchValue2] = useState("");
  const [secLsjl, setSecLsjl] = useState([]);

  useEffect(() => {
    axios.get("/ywg/api/hot/keywordlist.htm").then((response) => {
      console.log(response.data.common.slice(0, 5));
      setHotList(response.data.common.slice(0, 5));
    });
  }, []);

  const handleClearClick = () => {
    store.dispatch(clearHSearchValue());
  };
  const handleSearch = (value) => {
    setShowHotList(false);
    setSecResult(value);
    setSecLsjl(store.getState().searchValue)
  };
  const handleHotItemClick = (item) => {
    const targetText = item.target;
     console.log(targetText);
     setSearchValue2(targetText); // 将 targetText 设置为输入框的值
};
  return (
    <div>
      <SearchBar onSearch={handleSearch} searchValue2={searchValue2} />
      <div className="sec_tabs">
        <SecTabs />
      </div>
      {showHotList ? (
        <div>
        <div className="hot_list">
          {hotList.map((item, index) => (
            <div key={index} onClick={() => handleHotItemClick(item)}>
              <div>{item.target}</div>
            </div>
          ))}
        </div>  
          <div>
          <button onClick={handleClearClick}>删除记录</button>
          {secLsjl.map((item, index) => (
            <div key={index} onClick={() => handleHotItemClick(item)}>
              <div>{item}</div>
            </div>
           ))}
            </div> 
          </div> 
      ) : (
        <div className="tb_s1">
          <div className="tab-wrapper">
            <div className="mk_goods">商品</div>
            <div className="mk_shops">商铺</div>
          </div>
          <GoodsBox goodsList={secResult} />
        </div>
      )}
    </div>
  );
};

export default Search;
