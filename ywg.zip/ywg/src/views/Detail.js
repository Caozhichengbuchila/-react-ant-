import React, { useEffect, useState } from "react";
import { useParams,useHistory } from "react-router-dom";
import axios from "axios";
import GoodImgsSwiper from "../coms/GoodImgsSwiper/GoodImgsSwiper";
import './CSS/Detail.css'
import Gosmit from "../coms/GoodsOnsubmit/Gosmit";
import { LeftOutline, ShopbagOutline } from 'antd-mobile-icons'

const Detail = () => {
  const [gdimages, setGdimages] = useState([]);
  const [dt, setDt] = useState([])
  const [shop, setShop] = useState([])
  const { productId } = useParams();
  const history = useHistory();
  useEffect(() => {
    axios
      .get(`/ywg/api/product/detail.htm?productId=${productId}&newpd=1`)
      .then((response) => {
        const { picture, picture1, picture2, picture3, picture4 } = response.data.detail.productDetailVO;
        const newGdimages = [picture, picture1, picture2, picture3, picture4];
        console.log(response.data.detail.productDetailVO);
        if (JSON.stringify(newGdimages) !== JSON.stringify(gdimages)) {// 只在数据变化时更新状态
          setGdimages(newGdimages);
          setDt(response.data.detail.productDetailVO)
          setShop(response.data.shopinfo.shop)
        }
      })
  }, [gdimages, productId]);
  return (
    <div>
      <GoodImgsSwiper gdimages={gdimages} />
      {/* 标题 */}
      <div className="panel">
        <div className="title-con">
          <div className="dt_title">
            {dt.title}
          </div>
        </div>
        {/* 价格 */}
        <div className="price_box">
          <div className="price-type range-price-con">
            <div className="range-price-item">
              <div className="start-number">60套 起批</div>
              <div className="price-desc">
                ¥
                <span className="price">24.00</span>
              </div>
            </div>
            <div className="range-price-item">
              <div className="start-number">240 ~ 1199套</div>
              <div className="price-desc">
                ¥
                <span className="price">23.00</span></div></div><div className="range-price-item"><div className="start-number">≥ 1200套</div> <div className="price-desc">
                  ¥
                  <span className="price">21.00</span></div></div></div></div>
        {/* 发货 */}
        <div style={{ borderBottom: "0.7px solid #999" }}> <div className="extra-con"><div className="stock">供货量 {dt.saleNumber}套</div> <div className="freight"><div className="freight-panel"> <span>
          发往浙江 ¥<span>5.00</span></span></div></div></div></div>
        {/* 7天无理由 */}
        <div className="delivery-promise"><div><span>48h发货</span> <span>· 极速退款</span> <span>· 不支持7天无理由退货</span> <span></span> <span></span></div> <span className="icon-right">&#62;</span></div>
      </div>
      {/* 主体 */}
      <div className="coupon_content">
        {/* 评价 */}
        <div className="isolating_bar"></div>
        <div className="pal_rate"><div className="rate_title"><span>订单评价 (0)</span> <a href="/#">查看全部<i className="iconfont icon-right"></i></a></div> <div className="rate_content"><div className="noData">
          暂无评价
        </div></div></div>
        <div className="isolating_bar"></div>
        {/* 货号 */}
        <div className="pal_rate"><div className="product-code"><span>货号</span> <span className="code">{dt.goodsCode}</span></div></div>
        <div className="isolating_bar"></div>
        {/* 店家*/}
        <div className="pal_rate"><div className="shop-con"><div className="left">
          <img src={shop.pictureUrlA} alt='' className="xixi" /></div> <div className="right"><div className="shop-name"><span>{shop.shopName
          }</span>  <span className="years">11年</span></div> <div className="shop-address">地址：义乌国际商贸城四区86门4楼20街48765</div></div></div></div>
        {/* 联系 */}
        <div className="isolating_bar"></div>
        <div className="pal_rate"><div className="intro">【丹娜舒情趣内衣】掌柜提醒：情趣系列厂家直销，产品均有现货!也可来样订做，打版！ 实体商铺生意忙，有时客服无法及时回复留言！ 直接联系：15158934508 微信号码：15158934508咨询QQ：1303887798 商铺地址：义乌国际商贸城四区88门4楼20街48765--48766</div></div>
        <div className="isolating_bar"></div>
        {/* 商品详情 */}
        <div className="pal_rate">
          <div className="detail-title">商品详情</div>
          <div className="detail-content">
            <img src={gdimages[0]} alt="" className='ha1' />
             {/* 相似商品 */}   
<div>
  <span>相似商品</span>

</div>
          </div>
        </div>
      </div>
      <div className="f1"><Gosmit /></div>
      <div className="dt_btn_box">
        <div onClick={() => history.goBack()}><LeftOutline fontSize={25} color='white' /></div>
        <div><ShopbagOutline fontSize={25} color='white' /></div>
      </div>

    </div>
  )
}
export default Detail;