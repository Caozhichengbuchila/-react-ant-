import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import './CSS/Mk.css'
import GoodsBox from "../coms/goodsBox/GoodsBox.jsx";

const Mk = () => {
  const { id } = useParams();
  const [marketList, setMarketList] = useState([]);
  const [numfound,setNumfound]=useState('');
  const [prslist, setPrslist] = useState([]);

  useEffect(() => {
    //floor数据
    axios
      .get(`/ywg/api/index/marketList.htm?subMarket=${id}&marketCode=10`)
      .then((response) => {
        const data = response.data.data.listMarket;
        //console.log(response.data.data.listMarket);
        let result = [];
        for (let marketData of data) {
          for (let floor in marketData) {
            let industries = marketData[floor];
            let industryNames = industries.map((industry) => industry.industryName).join(", ");
            result.push(
              <div key={`${floor}${marketData.marketName}`} className='mksdata'>
                <p><span className="floor">{floor}F</span><span>{marketData.marketName}: {industryNames}</span></p> 
              </div>
            );
          }
        }
        setMarketList(result);
      });

      //list数据
      axios
      .get(`/ywg/api/product/list3.htm?q=&pageSize=28&st=0&m=${id}&f=&s=&imei=360755bd-f368-46ee-9e0d-c3c35b53ca2f&source=wap&userinfo=&searchMethod=randad&marketCode=10&code=1001&spm=d2FwLnlpd3Vnby5jb20v&cpage=1`)
      .then((response) => {
        console.log(response.data.data.prslist);
          setNumfound(response.data.data.numfound)
          setPrslist(response.data.data.prslist)
      });
  }, [id]);
  return ( 
  <div> 
    <div>{marketList}</div>  
    <div className="tab-wrapper">
      <div className="mk_goods">商品({numfound})</div>
      <div className="mk_shops">商铺(1000)</div>
    </div>
    <GoodsBox  goodsList={prslist} />   
    </div>
    )

 
};

export default Mk;
