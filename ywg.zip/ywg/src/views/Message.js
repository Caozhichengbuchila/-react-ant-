import React from "react";
const Message =()=>{
    return(
        <div>
            <h1>消息</h1>
        </div>
    )
}
export default Message;
