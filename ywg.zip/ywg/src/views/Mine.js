import React from "react";
const Mine =()=>{
    return(
        <div>
            <h1>我的</h1>
        </div>
    )
}
export default Mine;
