import React, { useEffect, useState } from "react";
import SearchBar from "../coms/searchBar/SearchBar.jsx";
import NavBar from "../coms/NavBar/NavBar";
import Markets from "../coms/Markets/Markets";
import FootBar from "../coms/FootBar/FootBar";
import "./CSS/Home.css";
import axios from "axios";
import GoodsBox from "../coms/goodsBox/GoodsBox.jsx";

const Home = () => {
  const [goodsList, setGoodsList] = useState([]);
  useEffect(() => {
    axios
      .get(
        "/ywg/api/index/recommProductAndShop.htm?cpage=1&currPage=1&pageSize=30&searchMethod=randad&userId=360755bd-f368-46ee-9e0d-c3c35b53ca2f&marketCode=10"
      )
      .then((response) => {
        const newGoodsList = response.data.data.list.flatMap((goods) =>
          goods.recommProductBoList
        );//response.data.data.list{[]...[{XXX,"recommProductBoList":[{"id":,YYY,}]},XXZX]..[]}
        setGoodsList(newGoodsList);
         // 发起第二次请求获取第二页的数据
      axios
      .get(
        "/ywg/api/index/recommProductAndShop.htm?cpage=2&currPage=2&pageSize=30&searchMethod=randad&userId=360755bd-f368-46ee-9e0d-c3c35b53ca2f&marketCode=10"
      )
      .then((response) => {
        const nextPageGoodsList = response.data.data.list.flatMap((goods) =>
          goods.recommProductBoList
        );
        setGoodsList((prevGoodsList) => [...prevGoodsList, ...nextPageGoodsList]);
      });
      });
  }, []);

  return (
    <div>
      <SearchBar />
      <div className="main_page">
        <div className="nav_bar">
          <NavBar />
        </div>
        <div className="mks">
          <Markets />
        </div>
      </div>
       <GoodsBox  goodsList={goodsList} />   
      <div className="foot_bar">
        <FootBar />
      </div>
    </div>
  );
};

export default Home;
