import React, {useState} from 'react';
import { SideBar } from 'antd-mobile';
import './CSS/cate.css'

function Cate() {
const [activeKey, setActiveKey] = useState('key1'); // 用 state 存储当前激活项的 key
const tabs = [
{
key: 'key1',
title: '化妆品',
content: [
{
"id": 918,
"type": "假发",
"typeUrl": "假发",
"typeId": "1",
"img": "https://img1.yiwugou.com/i004/2018/04/18/01/894f281b52cc1b98d092d22cc57eaf51.jpg@800w.jpg",
"rank": "1009",
"uppertype": "988",
"uppertypeName": "化妆品",
"entype": "",
"productTypeList": null
},
]
},
{
key: 'key2',
title: '药品',
content: [
{
"id": 999,
"type": "风油精",
"typeUrl": "风油精",
"typeId": "1",
"img": "https://img1.yiwugou.com/i004/2023/04/18/53/f7ae77a93c67e2e74d503d8069f6f1c6.jpg",
"rank": "1",
"uppertype": "998",
"uppertypeName": "药品",
"entype": null,
"productTypeList": null
},
]
},
{
key: 'key3',
title: '地摊摆货',
content: [
{
"id": 976,
"type": "发光玩具",
"typeUrl": "发光玩具",
"typeId": "1",
"img": "https://img1.yiwugou.com/i004/2020/06/04/85/52ac81459c3625a82e1404afd1855d47.png",
"rank": "1",
"uppertype": "946",
"uppertypeName": "地摊挑货",
"entype": null,
"productTypeList": null
},
]
},
];

const handleTabClick = (key) => {
setActiveKey(key); // 更新当前激活项的 key
}

return (
<div>
<h1>分类页</h1>
<SideBar activeKey={activeKey} onChange={handleTabClick}>
{tabs.map(item => (
<SideBar.Item key={item.key} title={item.title} />
))}
</SideBar>
<div>
{tabs.find(item => item.key === activeKey).content.map((item) => {
let img = item.img;
let newImg = img;
let index = img.indexOf('?');
if (index !== -1) {
newImg = img.slice(0, index);
}
if (!img.startsWith('http')) {
newImg = `https://img1.yiwugou.com/${img}`;
}
return (
<div className='catepage'>
<div key={item.id} className='cate_item'>
  <img src={newImg} alt={item.typeUrl} />
  {/* 解决渲染图片403报错 */}
  <meta name="referrer" content="no-referrer"></meta>
  <div>{item.typeUrl}</div> 
</div>


</div>
);
})}
</div>
</div>
);
}

export default Cate;

