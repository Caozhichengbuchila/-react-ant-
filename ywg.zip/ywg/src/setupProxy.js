let {createProxyMiddleware} =require('http-proxy-middleware');
// 配置方式和配置项和vue的代理一样
module.exports =function(app){
    app.use(
        createProxyMiddleware("/ywg",{
            target:"https://wap.yiwugo.com",
            changeOrigin:true,
            pathRewrite:{
                "^/ywg":""
            }
        })
    )
}